export default function main() {
  console.log('Hello, tacer')
}
